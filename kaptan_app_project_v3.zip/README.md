Jarvis - Android prototype v3
=========================================
This updated source includes:
 - App default name: Jarvis
 - Default wake-word: "Jarvis" (configurable in app UI)
 - OpenAI integration using Retrofit (uses BuildConfig.OPENAI_API_KEY)
 - Node.js backend proxy example at /backend (recommended to avoid embedding API keys)
 - "Jarvis dur" voice command to stop listening
 - TTS responses prefixed to sound natural/samimi

Important:
 - This environment cannot build an APK. Open the project in Android Studio and build.
 - To provide an OpenAI key to the Android app (NOT recommended), add the following to your `~/.gradle/gradle.properties`:
     OPENAI_API_KEY="sk-...."
   Then in the project's `app/build.gradle`, the buildConfigField will pick it up.
 - Recommended: run the Node.js backend (backend/server.js) and set OPENAI_API_KEY in the backend's environment, then set the app to call the backend endpoint (see README below).
 - After opening in Android Studio, paste a Vosk model into app/src/main/assets/model if you will use offline ASR; by default the app uses Android's SpeechRecognizer as a fallback for demo.

Quick steps to run backend (optional, recommended to avoid embedding keys):
 1. cd backend
 2. npm install
 3. export OPENAI_API_KEY="sk-..."
 4. node server.js
 Backend listens on port 3000 by default and proxies /chat.

Build notes:
 - Open in Android Studio, let Gradle sync.
 - Set OPENAI_API_KEY in gradle.properties if you insist on embedding (not secure).
 - Run on a real Android device.

