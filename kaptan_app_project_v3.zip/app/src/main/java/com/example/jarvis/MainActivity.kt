package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.os.PowerManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityCompat
import android.content.pm.PackageManager
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private val REQ_AUDIO = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        val edit = EditText(this)
        edit.hint = "Wake-word (ör: "Jarvis") - boş bırakılırsa varsayılan kullanılacak"
        val btn = Button(this)
        btn.text = "Başlat"
        layout.addView(edit)
        layout.addView(btn)
        setContentView(layout)

        val wakeWord = edit.text.toString().trim()
        btn.setOnClickListener {
            val chosen = if (wakeWord.isBlank()) "Jarvis" else wakeWord
            val prefs = getSharedPreferences("jarvis_prefs", MODE_PRIVATE)
            prefs.edit().putString("wake_word", chosen).apply()
            startVoiceServiceIfAllowed()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
        }
    }

    private fun startVoiceServiceIfAllowed() {
        val intent = Intent(this, VoiceService::class.java)
        ContextCompat.startForegroundService(this, intent)

        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
            val i = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            startActivity(i)
        }
    }
}
