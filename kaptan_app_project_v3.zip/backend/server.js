// Simple proxy to OpenAI Chat Completions. Set OPENAI_API_KEY in env.
const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const OPENAI_KEY = process.env.OPENAI_API_KEY;
if (!OPENAI_KEY) {
  console.warn("WARNING: OPENAI_API_KEY not set in environment. Set it before running.");
}

app.post('/chat', async (req, res) => {
  try {
    const messages = req.body.messages || [{role: "user", content: req.body.prompt}];
    const resp = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-4o-mini",
      messages: messages,
      max_tokens: 500
    }, {
      headers: {
        Authorization: `Bearer ${OPENAI_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    res.json(resp.data);
  } catch (err) {
    console.error(err?.response?.data || err.message);
    res.status(500).json({error: 'OpenAI request failed', details: err?.response?.data || err.message});
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Jarvis backend listening on ${PORT}`));
